"use client";

import { useEffect, useRef, useState, FormEvent } from "react";
import TopBar from "@/app/components/TopBar";
import Viewfinder from "@/app/components/Viewfinder";
import ContactSheet, { Take } from "@/app/components/ContactSheet";

type Phase = "idle" | "starting" | "generating" | "ready" | "error";

const STORAGE_KEY = "rolling.takes.v1";
const POLL_MS = 5000;
const MAX_POLL_MS = 8 * 60 * 1000; // give up after 8 minutes

export default function Home() {
  const [prompt, setPrompt] = useState("");
  const [phase, setPhase] = useState<Phase>("idle");
  const [videoId, setVideoId] = useState<string | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [thumbnailUrl, setThumbnailUrl] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [startedAt, setStartedAt] = useState<number | null>(null);
  const [takes, setTakes] = useState<Take[]>([]);

  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const currentPromptRef = useRef("");

  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setTakes(JSON.parse(raw));
    } catch {
      // ignore corrupt local storage
    }
  }, []);

  useEffect(() => {
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, []);

  function persistTake(take: Take) {
    setTakes((prev) => {
      const next = [take, ...prev].slice(0, 24);
      try {
        window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        // storage full or unavailable — skip persistence silently
      }
      return next;
    });
  }

  function stopPolling() {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const trimmed = prompt.trim();
    if (!trimmed || phase === "starting" || phase === "generating") return;

    currentPromptRef.current = trimmed;
    setPhase("starting");
    setErrorMessage(null);
    setVideoUrl(null);
    setThumbnailUrl(null);
    setStartedAt(Date.now());

    try {
      const resp = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: trimmed }),
      });
      const data = await resp.json();

      if (!resp.ok) {
        setPhase("error");
        setErrorMessage(data?.error ?? "Something went wrong starting the render.");
        return;
      }

      setVideoId(data.videoId);
      setPhase("generating");
      beginPolling(data.videoId);
    } catch {
      setPhase("error");
      setErrorMessage("Could not reach the server. Check your connection and try again.");
    }
  }

  function beginPolling(id: string) {
    const deadline = Date.now() + MAX_POLL_MS;
    stopPolling();
    pollRef.current = setInterval(async () => {
      if (Date.now() > deadline) {
        stopPolling();
        setPhase("error");
        setErrorMessage("This take is taking longer than expected. Check back later.");
        return;
      }
      try {
        const resp = await fetch(`/api/status/${id}`, { cache: "no-store" });
        const data = await resp.json();

        if (!resp.ok) {
          stopPolling();
          setPhase("error");
          setErrorMessage(data?.error ?? "Lost contact with HeyGen mid-render.");
          return;
        }

        if (data.status === "completed") {
          stopPolling();
          setPhase("ready");
          setVideoUrl(data.videoUrl);
          setThumbnailUrl(data.thumbnailUrl ?? null);
          persistTake({
            id,
            prompt: currentPromptRef.current,
            videoUrl: data.videoUrl,
            thumbnailUrl: data.thumbnailUrl ?? null,
            createdAt: Date.now(),
          });
        } else if (data.status === "failed") {
          stopPolling();
          setPhase("error");
          setErrorMessage(
            data.failureMessage ?? "The render failed. Try a different prompt."
          );
        }
        // pending / processing → keep polling
      } catch {
        // transient network hiccup — let the next tick retry
      }
    }, POLL_MS);
  }

  function handleSelectTake(take: Take) {
    stopPolling();
    setVideoId(take.id);
    setVideoUrl(take.videoUrl);
    setThumbnailUrl(take.thumbnailUrl);
    setPhase("ready");
    setPrompt(take.prompt);
  }

  const isBusy = phase === "starting" || phase === "generating";

  return (
    <main className="min-h-screen">
      <TopBar phase={phase} />

      <div className="mx-auto max-w-3xl px-6 py-10 sm:px-10 sm:py-14">
        <form onSubmit={handleSubmit}>
          <label
            htmlFor="prompt"
            className="mb-2 block font-mono text-[11px] tracking-widest2 text-muted"
          >
            PROMPT
          </label>
          <textarea
            id="prompt"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="A presenter explaining our product launch in 30 seconds…"
            rows={4}
            maxLength={1000}
            disabled={isBusy}
            className="w-full resize-none rounded-sm border border-line bg-panel px-4 py-3 font-body text-sm text-paper placeholder:text-muted/60 focus:border-paper/50 focus:outline-none disabled:opacity-60"
          />
          <div className="mt-3 flex items-center justify-between">
            <span className="font-mono text-[10px] text-muted">
              {prompt.length}/1000
            </span>
            <button
              type="submit"
              disabled={isBusy || prompt.trim().length === 0}
              className="flex items-center gap-2 rounded-sm bg-tally px-5 py-2.5 font-display text-sm font-bold uppercase tracking-widest2 text-paper transition hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <span className="h-2 w-2 rounded-full bg-paper" />
              {isBusy ? "Rolling…" : "Roll"}
            </button>
          </div>
        </form>

        <div className="mt-8">
          <Viewfinder
            phase={phase}
            startedAt={startedAt}
            videoUrl={videoUrl}
            thumbnailUrl={thumbnailUrl}
            errorMessage={errorMessage}
          />
        </div>

        <ContactSheet takes={takes} onSelect={handleSelectTake} />

        <p className="mt-12 text-center font-mono text-[10px] text-muted">
          Powered by the HeyGen Video Agent API
        </p>
      </div>
    </main>
  );
}
