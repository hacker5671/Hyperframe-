"use client";

export type Take = {
  id: string;
  prompt: string;
  videoUrl: string;
  thumbnailUrl: string | null;
  createdAt: number;
};

export default function ContactSheet({
  takes,
  onSelect,
}: {
  takes: Take[];
  onSelect: (take: Take) => void;
}) {
  if (takes.length === 0) return null;

  return (
    <div className="mt-10">
      <div className="mb-3 flex items-center gap-3">
        <p className="font-mono text-[11px] tracking-widest2 text-muted">
          TAKES — {takes.length.toString().padStart(2, "0")}
        </p>
        <div className="h-px flex-1 bg-line" />
      </div>
      <div className="flex gap-3 overflow-x-auto pb-2">
        {takes.map((take, i) => (
          <button
            key={take.id}
            onClick={() => onSelect(take)}
            className="group relative flex-shrink-0 overflow-hidden rounded-sm border border-line bg-panel transition hover:border-paper/40"
            style={{ width: 160 }}
          >
            <div className="relative aspect-video w-full bg-raised">
              {take.thumbnailUrl && (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={take.thumbnailUrl}
                  alt={take.prompt}
                  className="h-full w-full object-cover opacity-80 transition group-hover:opacity-100"
                />
              )}
              <span className="absolute left-1.5 top-1.5 font-mono text-[9px] text-paper/70">
                {String(takes.length - i).padStart(2, "0")}
              </span>
            </div>
            <p className="truncate px-2 py-1.5 text-left font-mono text-[10px] text-muted">
              {take.prompt}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
}
