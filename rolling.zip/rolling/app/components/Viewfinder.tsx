"use client";

import { useEffect, useState } from "react";
import { toTimecode } from "@/lib/timecode";

type Phase = "idle" | "starting" | "generating" | "ready" | "error";

export default function Viewfinder({
  phase,
  startedAt,
  videoUrl,
  thumbnailUrl,
  errorMessage,
}: {
  phase: Phase;
  startedAt: number | null;
  videoUrl: string | null;
  thumbnailUrl: string | null;
  errorMessage: string | null;
}) {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    if (phase !== "starting" && phase !== "generating") return;
    const started = startedAt;
    if (started === null) return;
    const id = setInterval(() => setElapsed(Date.now() - started), 83);
    return () => clearInterval(id);
  }, [phase, startedAt]);

  const frameClass =
    phase === "starting" || phase === "generating"
      ? "is-live"
      : phase === "ready"
      ? "is-ready"
      : "";

  return (
    <div className="w-full">
      <div
        className={`viewfinder crt relative aspect-video w-full overflow-hidden rounded-sm border border-line bg-panel ${frameClass}`}
      >
        <span className="bracket-tr" />
        <span className="bracket-br" />

        {phase === "idle" && (
          <div className="flex h-full w-full flex-col items-center justify-center gap-2 text-muted">
            <div className="h-3 w-3 rounded-full border border-muted" />
            <p className="font-mono text-xs tracking-widest2">NO SIGNAL</p>
          </div>
        )}

        {(phase === "starting" || phase === "generating") && (
          <div className="flex h-full w-full flex-col items-center justify-center gap-3">
            <div className="flex items-center gap-2">
              <span className="h-2.5 w-2.5 rounded-full bg-tally animate-pulseTally" />
              <span className="font-mono text-xs tracking-widest2 text-paper">
                {phase === "starting" ? "SLATING" : "GENERATING"}
              </span>
            </div>
            <p className="font-mono text-2xl tabular-nums text-paper">
              {toTimecode(elapsed)}
            </p>
            <p className="max-w-xs text-center font-body text-xs text-muted">
              The agent is scripting, casting a presenter, and rendering the
              take. Most clips finish in 1–5 minutes.
            </p>
          </div>
        )}

        {phase === "ready" && videoUrl && (
          <video
            className="h-full w-full object-cover"
            src={videoUrl}
            poster={thumbnailUrl ?? undefined}
            controls
            playsInline
          />
        )}

        {phase === "error" && (
          <div className="flex h-full w-full flex-col items-center justify-center gap-2 px-8 text-center">
            <span className="h-2.5 w-2.5 rounded-full bg-tally" />
            <p className="font-mono text-xs tracking-widest2 text-tally">CUT</p>
            <p className="max-w-sm text-xs text-muted">{errorMessage}</p>
          </div>
        )}
      </div>
    </div>
  );
}
