"use client";

import { useEffect, useState } from "react";
import { clockTimecode } from "@/lib/timecode";

type Phase = "idle" | "starting" | "generating" | "ready" | "error";

const STATUS_COPY: Record<Phase, { label: string; dot: string }> = {
  idle: { label: "STANDBY", dot: "bg-muted" },
  starting: { label: "ROLLING", dot: "bg-tally animate-pulseTally" },
  generating: { label: "RECORDING", dot: "bg-tally animate-pulseTally" },
  ready: { label: "CLEAR", dot: "bg-ready" },
  error: { label: "CUT", dot: "bg-tally" },
};

export default function TopBar({ phase }: { phase: Phase }) {
  const [now, setNow] = useState<string>("");

  useEffect(() => {
    setNow(clockTimecode(new Date()));
    const id = setInterval(() => setNow(clockTimecode(new Date())), 1000);
    return () => clearInterval(id);
  }, []);

  const status = STATUS_COPY[phase];

  return (
    <header className="flex items-center justify-between border-b border-line px-6 py-4 sm:px-10">
      <div className="flex items-baseline gap-3">
        <span className="font-display text-2xl font-bold uppercase tracking-widest2 text-paper">
          Rolling
        </span>
        <span className="hidden font-mono text-xs text-muted sm:inline">
          prompt → video
        </span>
      </div>
      <div className="flex items-center gap-4">
        <span className="font-mono text-xs tabular-nums text-muted">{now}</span>
        <span className="flex items-center gap-2 rounded-full border border-line bg-panel px-3 py-1">
          <span className={`h-2 w-2 rounded-full ${status.dot}`} />
          <span className="font-mono text-[11px] tracking-widest2 text-paper">
            {status.label}
          </span>
        </span>
      </div>
    </header>
  );
}
