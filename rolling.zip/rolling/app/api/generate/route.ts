import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";

const HEYGEN_BASE = "https://api.heygen.com";

export async function POST(req: NextRequest) {
  const apiKey = process.env.HEYGEN_API_KEY;
  if (!apiKey) {
    return NextResponse.json(
      {
        error:
          "HEYGEN_API_KEY is not set. Add it under Vercel → Project → Settings → Environment Variables and redeploy.",
      },
      { status: 500 }
    );
  }

  let prompt: unknown;
  try {
    const body = await req.json();
    prompt = body?.prompt;
  } catch {
    return NextResponse.json({ error: "Invalid request body." }, { status: 400 });
  }

  if (typeof prompt !== "string" || prompt.trim().length === 0) {
    return NextResponse.json({ error: "A prompt is required." }, { status: 400 });
  }
  if (prompt.length > 1000) {
    return NextResponse.json(
      { error: "Keep prompts under 1000 characters." },
      { status: 400 }
    );
  }

  try {
    const resp = await fetch(`${HEYGEN_BASE}/v3/video-agents`, {
      method: "POST",
      headers: {
        "X-Api-Key": apiKey,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ prompt: prompt.trim() }),
    });

    const payload = await resp.json().catch(() => null);

    if (!resp.ok) {
      const message =
        payload?.error?.message ||
        payload?.message ||
        `HeyGen rejected the request (${resp.status}).`;
      return NextResponse.json({ error: message }, { status: resp.status });
    }

    const data = payload?.data;
    if (!data?.video_id) {
      return NextResponse.json(
        { error: "HeyGen did not return a video_id." },
        { status: 502 }
      );
    }

    return NextResponse.json({
      videoId: data.video_id as string,
      sessionId: data.session_id as string | undefined,
      status: data.status as string | undefined,
    });
  } catch (err) {
    return NextResponse.json(
      { error: "Could not reach HeyGen. Try again in a moment." },
      { status: 502 }
    );
  }
}
